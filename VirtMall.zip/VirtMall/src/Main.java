public class Main {
    public static void main(String[] args) {

        System.out.println("     Welcome to Matthew and Josh's Shopping Mall!     ");
        System.out.println("------------------------------------------------------");
        System.out.println("            We have everything you need!     ");
        System.out.println("                      ");
        System.out.println("Categories and Stores:");
        System.out.println("Sports:");
        System.out.println("   - Small 5: Floor 1");
        System.out.println("   - Abibas: Floor 2");
        System.out.println("   - Mike, Just Give Up: Floor 1");
        System.out.println("Fashion: ");
        System.out.println("   - Suburban Outfitters: Floor 3");
        System.out.println("   - Pacmoon: Floor 2");
        System.out.println("   - Victor's Secret: Floor 3 ");
        System.out.println("Electronics: ");
        System.out.println("   - Pear: Floor 2");
        System.out.println("   - Samsuck: Floor 2");
        System.out.println("   - iPear Repair: Floor 3 ");
        System.out.println("Department: ");
        System.out.println("   - Off-target: Floor 3");
        System.out.println("   - Seers: Floor 3");
        System.out.println("   - Nordshroom: Floor 3 ");
        System.out.println("Grocery: ");
        System.out.println("   - Seafood Village: Floor 1");
        System.out.println("   - Unsafe Way: Floor 1");
        System.out.println("   - Great Wall Ranch 100: Floor 1 ");
        System.out.println("Promotions and Events: ");
        System.out.println("   - Buy one get one 50% off at Pacmoon until December 31!");
        System.out.println("   - 70% off everything! Massive White Friday Sale at Abibas!");
        System.out.println("   - 10% off your whole purchase with a minimum order of $10 at Seafood Village!");



    }
}